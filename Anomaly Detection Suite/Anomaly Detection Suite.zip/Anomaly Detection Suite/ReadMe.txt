Double click on UserInterface.py to launch the program.
When using the Anomaly Detection Suite for the first time it is important to first look at the developer tools. 
	1. Train a new vectorizer model
	2. Train a new binomial model
	3. Train a new multinomial model
With these steps completed you can then predict new log files.